from .pdf_analyzer_module import PDFAnalyzer
# from pdf_analyzer import LinkAnalyzer

class PDFAnalyzer(PDFAnalyzer):
    pass





