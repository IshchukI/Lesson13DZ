from .pdf_analyzer_module import PDFAnalyzer

class PDFAnalyzer(PDFAnalyzer):
    pass





