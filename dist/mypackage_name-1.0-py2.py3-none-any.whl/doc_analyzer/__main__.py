if __name__ == "__main__":
    print("Run mypackage")
    print("Done")

